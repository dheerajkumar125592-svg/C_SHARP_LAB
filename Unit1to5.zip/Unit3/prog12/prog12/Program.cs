﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number, sum = 0, digit;

            Console.Write("Enter a number: ");
            number = Convert.ToInt32(Console.ReadLine());

            while (number > 0)
            {
                digit = number % 10;  
                sum = sum + digit;   
                number = number / 10; 
            }

            Console.WriteLine("Sum of digits = " + sum);
        }
    }
}
    

