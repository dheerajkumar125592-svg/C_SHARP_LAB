﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input, reverse = "";

            Console.Write("Enter a string: ");
            input = Console.ReadLine();

            for (int i = input.Length - 1; i >= 0; i--)
            {
                reverse = reverse + input[i];
            }

            if (input.Equals(reverse, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("It is palindrome");
            }
            else
            {
                Console.WriteLine("It is not palindrome");
            }
        }
    }
}
    

