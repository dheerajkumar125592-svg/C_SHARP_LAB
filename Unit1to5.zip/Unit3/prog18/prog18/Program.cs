﻿using System;

class Program
{
    static void Main()
    {
        string str, reverse = "";

        Console.Write("Enter a string: ");
        str = Console.ReadLine();

       
        for (int i = str.Length - 1; i >= 0; i--)
        {
            reverse += str[i];
        }

      
        if (str.Equals(reverse, StringComparison.OrdinalIgnoreCase))
            Console.WriteLine("It is palindrome");
        else
            Console.WriteLine("It is not palindrome");
    }
}