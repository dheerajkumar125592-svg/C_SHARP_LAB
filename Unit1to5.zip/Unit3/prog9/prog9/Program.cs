﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, first = 0, second = 1, next;

            Console.Write("Enter the limit: ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Fibonacci Series:");

            for (int i = 1; i <= n; i++)
            {
                Console.Write(first + " ");
                next = first + second;
                first = second;
                second = next;
            }
        }
    }
}
    


