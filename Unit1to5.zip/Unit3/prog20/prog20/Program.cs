﻿using System;

class Program
{
    static void Main()
    {
        int num, original, remainder, sum = 0;

        Console.Write("Enter a number: ");
        num = Convert.ToInt32(Console.ReadLine());

        original = num;

        
        while (num > 0)
        {
            remainder = num % 10;
            sum = sum + (remainder * remainder * remainder);
            num = num / 10;
        }

       
        if (original == sum)
            Console.WriteLine("It is Armstrong");
        else
            Console.WriteLine("It is not Armstrong");
    }
}