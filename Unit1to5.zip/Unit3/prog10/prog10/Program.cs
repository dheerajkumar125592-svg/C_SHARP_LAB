﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prog10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number, i;
            bool isPrime = true;

            Console.Write("Enter a number: ");
            number = Convert.ToInt32(Console.ReadLine());

            if (number <= 1)
            {
                isPrime = false;
            }
            else
            {
                for (i = 2; i <= number / 2; i++)
                {
                    if (number % i == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
            }

            if (isPrime)
            {
                Console.WriteLine("The number is Prime.");
            }
            else
            {
                Console.WriteLine("The number is Not Prime.");
            }
        }
    }
}


